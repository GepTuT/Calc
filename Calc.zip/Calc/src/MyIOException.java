import java.io.IOException;

public class MyIOException extends Exception {
    public MyIOException(String description) {
        super(description);
    }
}

